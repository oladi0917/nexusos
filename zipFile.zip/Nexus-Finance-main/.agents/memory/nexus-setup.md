---
name: Nexus project setup
description: Key decisions and gotchas for the Nexus fintech Expo + Express app
---

## Auth
- JWT (7d), signed with `JWT_SECRET` env (fallback: hardcoded dev secret — change in prod)
- Stored in `expo-secure-store` on native, `localStorage` on web (Platform branch in AuthContext)
- `setAuthTokenGetter` and `setBaseUrl` called at module level in `context/AuthContext.tsx` AND `app/_layout.tsx` (safe to call twice)

## DB
- Schema in `lib/db/src/schema/` (users, accounts, transactions)
- After changing schema: run `pnpm run typecheck:libs` first, then `pnpm --filter @workspace/db run push`
- Balances stored as `numeric(15,2)` in Postgres; routes parse to `parseFloat` before returning

## Demo seed
- Triggered on signup via `seedUserData(userId, firstName, lastName)`
- Creates GTBank + Kuda accounts, 8 transactions spread over past 18 days

## Bank resolution (transfers)
- Currently simulated: deterministic name from account number char code checksum
- Ready to swap for Mono/Okra: replace `POST /transfers/resolve` route body

## Package versions
- `expo-secure-store` must be `~15.0.8` for Expo SDK 54 (pnpm may install newer — pin in catalog if needed)

**Why:** Newer expo-secure-store versions broke web bundling until pinned to SDK-matching version.
