const colors = {
  light: {
    // Legacy aliases
    text: "#FFFFFF",
    tint: "#C9A84C",

    // Core surfaces — pure black base
    background: "#0C0C0C",
    foreground: "#FFFFFF",

    // Cards — slightly lighter dark
    card: "#181818",
    cardForeground: "#FFFFFF",

    // Primary — near-black (for button/header bg)
    primary: "#0C0C0C",
    primaryForeground: "#FFFFFF",

    // Secondary — medium dark
    secondary: "#1E1E1E",
    secondaryForeground: "#FFFFFF",

    // Muted
    muted: "#1E1E1E",
    mutedForeground: "#888888",

    // Accent — gold
    accent: "#C9A84C",
    accentForeground: "#FFFFFF",

    // Destructive
    destructive: "#EF4444",
    destructiveForeground: "#FFFFFF",

    // Borders — subtle dark
    border: "#2A2A2A",
    input: "#2A2A2A",

    // Extended Nexus palette
    gold: "#C9A84C",
    goldDark: "#9A7828",
    goldLight: "#2C2010",  // dark gold tint for icon backgrounds
    navy: "#0C0C0C",       // kept as alias — used for header/button backgrounds
    navyLight: "#181818",  // card-level dark
    navyMid: "#222222",    // mid-dark
    success: "#10B981",
    successLight: "#0A2D22",   // dark success tint
    creditGreen: "#10B981",
    debitRed: "#EF4444",
  },

  radius: 16,
};

export default colors;
