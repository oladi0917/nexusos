import React from "react";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { useGetDashboard, getGetDashboardQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";
import { TransactionItem } from "@/components/TransactionItem";
import { NexusLogo } from "@/components/NexusLogo";

function formatBalance(n: number): string {
  return n.toLocaleString("en-NG", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export default function DashboardScreen() {
  const insets = useSafeAreaInsets();
  const colors = useColors();
  const { user } = useAuth();
  const qc = useQueryClient();
  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const { data: dashboard, isLoading, refetch } = useGetDashboard();

  const QUICK_ACTIONS = [
    { label: "Send", icon: "send" as const, onPress: () => router.push("/(tabs)/send") },
    { label: "Accounts", icon: "credit-card" as const, onPress: () => router.push("/(tabs)/accounts") },
    { label: "History", icon: "list" as const, onPress: () => router.push("/(tabs)/transactions") },
    { label: "Add", icon: "plus-circle" as const, onPress: () => router.push("/accounts/add") },
  ];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPad + 12, backgroundColor: colors.background }]}>
        <NexusLogo size="xs" showWordmark />
        <Pressable
          style={[styles.notifBtn, { backgroundColor: colors.card, borderColor: colors.border }]}
          onPress={() => router.push("/(tabs)/profile")}
        >
          <Feather name="bell" size={20} color={colors.foreground} />
        </Pressable>
      </View>

      {/* Greeting */}
      <View style={[styles.greeting, { paddingHorizontal: 20, paddingBottom: 8 }]}>
        <Text style={[styles.greetingText, { color: colors.mutedForeground }]}>Good day,</Text>
        <Text style={[styles.userName, { color: colors.foreground }]}>
          {user?.firstName ?? "User"} 👋
        </Text>
      </View>

      {/* Balance card */}
      <View style={[styles.balanceWrap, { paddingHorizontal: 20 }]}>
        <LinearGradient
          colors={[colors.gold, colors.goldDark ?? "#9A7828"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.balanceCard}
        >
          <View style={styles.balanceCircle1} />
          <View style={styles.balanceCircle2} />
          <Text style={styles.balanceLabel}>Total Balance</Text>
          {isLoading ? (
            <ActivityIndicator color="#FFF" style={{ marginVertical: 8 }} />
          ) : (
            <Text style={styles.balanceAmount}>
              ₦{formatBalance(dashboard?.totalBalance ?? 0)}
            </Text>
          )}
          <View style={styles.balanceRow}>
            <Text style={styles.balanceSub}>
              {dashboard?.accountCount ?? 0} account{dashboard?.accountCount !== 1 ? "s" : ""} connected
            </Text>
            <Text style={styles.balanceCurrency}>NGN</Text>
          </View>
        </LinearGradient>
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={{ paddingBottom: Platform.OS === "web" ? 100 : 100 }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={false}
            onRefresh={async () => {
              await qc.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
              await refetch();
            }}
            tintColor={colors.gold}
          />
        }
      >
        {/* Quick actions */}
        <View style={[styles.section, { paddingTop: 20 }]}>
          <View style={styles.quickActions}>
            {QUICK_ACTIONS.map((action) => (
              <Pressable
                key={action.label}
                style={({ pressed }) => [
                  styles.quickAction,
                  { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.8 : 1 },
                ]}
                onPress={action.onPress}
              >
                <View style={[styles.quickActionIcon, { backgroundColor: colors.goldLight }]}>
                  <Feather name={action.icon} size={20} color={colors.gold} />
                </View>
                <Text style={[styles.quickActionLabel, { color: colors.foreground }]}>{action.label}</Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Recent transactions */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Recent Activity</Text>
            <Pressable onPress={() => router.push("/(tabs)/transactions")}>
              <Text style={[styles.seeAll, { color: colors.gold }]}>See all</Text>
            </Pressable>
          </View>

          {isLoading ? (
            <ActivityIndicator color={colors.gold} style={{ marginTop: 20 }} />
          ) : !dashboard?.recentTransactions?.length ? (
            <View style={[styles.empty, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Feather name="inbox" size={28} color={colors.mutedForeground} />
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>No transactions yet</Text>
            </View>
          ) : (
            dashboard.recentTransactions.map((tx) => (
              <TransactionItem
                key={tx.id}
                type={tx.type as "credit" | "debit"}
                amount={tx.amount}
                description={tx.description}
                bankName={tx.bankName}
                bankColor={tx.bankColor}
                currency={tx.currency}
                date={tx.createdAt}
                category={tx.category}
                onPress={() => router.push(`/transactions/${tx.id}`)}
              />
            ))
          )}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingBottom: 16,
  },
  greeting: {},
  greetingText: { fontSize: 13, fontFamily: "Inter_400Regular", marginBottom: 2 },
  userName: { fontSize: 20, fontFamily: "Inter_700Bold" },
  notifBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  balanceWrap: { marginBottom: 4 },
  balanceCard: {
    borderRadius: 20,
    padding: 22,
    overflow: "hidden",
    shadowColor: "#C9A84C",
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.25,
    shadowRadius: 14,
    elevation: 6,
  },
  balanceCircle1: {
    position: "absolute",
    top: -50,
    right: -50,
    width: 160,
    height: 160,
    borderRadius: 80,
    backgroundColor: "rgba(255,255,255,0.1)",
  },
  balanceCircle2: {
    position: "absolute",
    bottom: -60,
    left: -40,
    width: 160,
    height: 160,
    borderRadius: 80,
    backgroundColor: "rgba(255,255,255,0.07)",
  },
  balanceLabel: { color: "rgba(255,255,255,0.8)", fontSize: 13, fontFamily: "Inter_500Medium", marginBottom: 6 },
  balanceAmount: {
    color: "#FFFFFF",
    fontSize: 34,
    fontFamily: "Inter_700Bold",
    letterSpacing: -1,
    marginBottom: 10,
  },
  balanceRow: { flexDirection: "row", justifyContent: "space-between" },
  balanceSub: { color: "rgba(255,255,255,0.75)", fontSize: 13, fontFamily: "Inter_400Regular" },
  balanceCurrency: { color: "rgba(255,255,255,0.75)", fontSize: 13, fontFamily: "Inter_500Medium" },
  scroll: { flex: 1 },
  section: { paddingHorizontal: 20, paddingTop: 24 },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 14,
  },
  sectionTitle: { fontSize: 17, fontFamily: "Inter_700Bold" },
  seeAll: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  quickActions: { flexDirection: "row", justifyContent: "space-between", gap: 10 },
  quickAction: {
    flex: 1,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: "center",
    paddingVertical: 14,
    paddingHorizontal: 8,
    gap: 8,
  },
  quickActionIcon: {
    width: 42,
    height: 42,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  quickActionLabel: { fontSize: 11, fontFamily: "Inter_500Medium", textAlign: "center" },
  empty: {
    borderRadius: 14,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 32,
    gap: 10,
  },
  emptyText: { fontSize: 14, fontFamily: "Inter_400Regular" },
});
