import React from "react";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { useListAccounts, getListAccountsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useColors } from "@/hooks/useColors";
import { AccountCard } from "@/components/AccountCard";
import { NexusLogo } from "@/components/NexusLogo";

function formatBalance(n: number | string): string {
  const v = typeof n === "string" ? parseFloat(n) : n;
  return v.toLocaleString("en-NG", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export default function AccountsScreen() {
  const insets = useSafeAreaInsets();
  const colors = useColors();
  const qc = useQueryClient();
  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const { data: accounts, isLoading, refetch } = useListAccounts();

  const totalBalance = (accounts ?? []).reduce(
    (sum, a) => sum + (typeof a.balance === "string" ? parseFloat(a.balance) : a.balance),
    0
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPad + 12, backgroundColor: colors.background }]}>
        <View style={styles.headerLeft}>
          <NexusLogo size="xs" />
          <View>
            <Text style={[styles.headerTitle, { color: colors.foreground }]}>My Accounts</Text>
            {!isLoading && (accounts ?? []).length > 0 && (
              <Text style={[styles.headerSub, { color: colors.mutedForeground }]}>
                Combined: ₦{formatBalance(totalBalance)}
              </Text>
            )}
          </View>
        </View>
        <Pressable
          style={({ pressed }) => [
            styles.addBtn,
            { backgroundColor: colors.gold, opacity: pressed ? 0.85 : 1 },
          ]}
          onPress={() => router.push("/accounts/add")}
        >
          <Feather name="plus" size={18} color="#FFF" />
          <Text style={styles.addBtnText}>Add</Text>
        </Pressable>
      </View>

      <ScrollView
        contentContainerStyle={{ padding: 20, paddingBottom: Platform.OS === "web" ? 100 : 100 }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={false}
            onRefresh={async () => {
              await qc.invalidateQueries({ queryKey: getListAccountsQueryKey() });
              await refetch();
            }}
            tintColor={colors.gold}
          />
        }
      >
        {isLoading ? (
          <ActivityIndicator color={colors.gold} style={{ marginTop: 40 }} />
        ) : !accounts?.length ? (
          <View style={[styles.empty, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Feather name="credit-card" size={36} color={colors.mutedForeground} />
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No accounts yet</Text>
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
              Connect your bank accounts to get started
            </Text>
            <Pressable
              style={({ pressed }) => [
                styles.connectBtn,
                { backgroundColor: colors.gold, opacity: pressed ? 0.85 : 1 },
              ]}
              onPress={() => router.push("/accounts/add")}
            >
              <Text style={styles.connectBtnText}>Connect Account</Text>
            </Pressable>
          </View>
        ) : (
          <View style={styles.cardList}>
            {accounts.map((account) => (
              <AccountCard
                key={account.id}
                bankName={account.bankName}
                bankColor={account.bankColor}
                accountNumber={account.accountNumber}
                accountName={account.accountName}
                balance={account.balance}
                currency={account.currency}
              />
            ))}
            <Pressable
              style={({ pressed }) => [
                styles.addMoreBtn,
                { borderColor: colors.gold, opacity: pressed ? 0.8 : 1 },
              ]}
              onPress={() => router.push("/accounts/add")}
            >
              <Feather name="plus" size={18} color={colors.gold} />
              <Text style={[styles.addMoreText, { color: colors.gold }]}>Add another account</Text>
            </Pressable>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingBottom: 16,
  },
  headerLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    flex: 1,
  },
  headerTitle: { fontSize: 22, fontFamily: "Inter_700Bold" },
  headerSub: { fontSize: 13, fontFamily: "Inter_400Regular", marginTop: 2 },
  addBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 10,
  },
  addBtnText: { color: "#FFF", fontSize: 14, fontFamily: "Inter_600SemiBold" },
  cardList: { gap: 16 },
  addMoreBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    borderWidth: 1.5,
    borderStyle: "dashed",
    borderRadius: 16,
    paddingVertical: 18,
    marginTop: 4,
  },
  addMoreText: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  empty: {
    borderRadius: 20,
    borderWidth: 1,
    alignItems: "center",
    padding: 40,
    marginTop: 40,
    gap: 12,
  },
  emptyTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  emptyText: { fontSize: 14, fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 20 },
  connectBtn: { borderRadius: 12, paddingVertical: 12, paddingHorizontal: 24, marginTop: 8 },
  connectBtnText: { color: "#FFF", fontSize: 14, fontFamily: "Inter_600SemiBold" },
});
