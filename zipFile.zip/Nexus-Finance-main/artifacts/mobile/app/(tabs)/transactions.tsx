import React, { useState } from "react";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import {
  useListTransactions,
  useListAccounts,
  getListTransactionsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useColors } from "@/hooks/useColors";
import { TransactionItem } from "@/components/TransactionItem";
import { NexusLogo } from "@/components/NexusLogo";

export default function TransactionsScreen() {
  const insets = useSafeAreaInsets();
  const colors = useColors();
  const qc = useQueryClient();
  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const [selectedAccountId, setSelectedAccountId] = useState<number | null>(null);
  const { data: accounts } = useListAccounts();
  const { data: transactions, isLoading, refetch } = useListTransactions(
    selectedAccountId ? { accountId: selectedAccountId } : undefined
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topPad + 12, backgroundColor: colors.background }]}>
        <NexusLogo size="xs" />
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Transactions</Text>
      </View>

      {(accounts?.length ?? 0) > 1 && (
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={styles.filterBar}
          contentContainerStyle={[styles.filterContent, { backgroundColor: colors.background }]}
        >
          <Pressable
            onPress={() => setSelectedAccountId(null)}
            style={[
              styles.filterChip,
              { backgroundColor: !selectedAccountId ? colors.gold : colors.card, borderColor: colors.border },
            ]}
          >
            <Text style={[styles.filterChipText, { color: !selectedAccountId ? "#FFF" : colors.mutedForeground }]}>
              All
            </Text>
          </Pressable>
          {accounts?.map((acc) => (
            <Pressable
              key={acc.id}
              onPress={() => setSelectedAccountId(acc.id)}
              style={[
                styles.filterChip,
                {
                  backgroundColor: selectedAccountId === acc.id ? colors.gold : colors.card,
                  borderColor: colors.border,
                },
              ]}
            >
              <View style={[styles.filterDot, { backgroundColor: acc.bankColor }]} />
              <Text style={[styles.filterChipText, { color: selectedAccountId === acc.id ? "#FFF" : colors.mutedForeground }]}>
                {acc.bankName.split(" ")[0]}
              </Text>
            </Pressable>
          ))}
        </ScrollView>
      )}

      <ScrollView
        contentContainerStyle={{ padding: 20, paddingBottom: Platform.OS === "web" ? 100 : 100 }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={false}
            onRefresh={async () => {
              await qc.invalidateQueries({ queryKey: getListTransactionsQueryKey() });
              await refetch();
            }}
            tintColor={colors.gold}
          />
        }
      >
        {isLoading ? (
          <ActivityIndicator color={colors.gold} style={{ marginTop: 40 }} />
        ) : !transactions?.length ? (
          <View style={[styles.empty, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Feather name="inbox" size={36} color={colors.mutedForeground} />
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No transactions</Text>
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
              Your transaction history will appear here
            </Text>
          </View>
        ) : (
          transactions.map((tx) => (
            <TransactionItem
              key={tx.id}
              type={tx.type as "credit" | "debit"}
              amount={tx.amount}
              description={tx.description}
              bankName={tx.bankName}
              bankColor={tx.bankColor}
              currency={tx.currency}
              date={tx.createdAt}
              category={tx.category}
              onPress={() => router.push(`/transactions/${tx.id}`)}
            />
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 12, flexDirection: "row", alignItems: "center", gap: 10 },
  headerTitle: { fontSize: 22, fontFamily: "Inter_700Bold" },
  filterBar: { maxHeight: 52 },
  filterContent: { paddingHorizontal: 20, paddingBottom: 10, gap: 8 },
  filterChip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 20,
    borderWidth: 1,
  },
  filterDot: { width: 8, height: 8, borderRadius: 4 },
  filterChipText: { fontSize: 13, fontFamily: "Inter_500Medium" },
  empty: {
    borderRadius: 20,
    borderWidth: 1,
    alignItems: "center",
    padding: 40,
    marginTop: 40,
    gap: 12,
  },
  emptyTitle: { fontSize: 18, fontFamily: "Inter_700Bold" },
  emptyText: { fontSize: 14, fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 20 },
});
