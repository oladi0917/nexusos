import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Feather } from "@expo/vector-icons";
import { useColors } from "@/hooks/useColors";

interface AccountCardProps {
  bankName: string;
  bankColor: string;
  accountNumber: string;
  accountName: string;
  balance: number | string;
  currency?: string;
  compact?: boolean;
  selected?: boolean;
  onPress?: () => void;
}

function formatBalance(bal: number | string): string {
  const n = typeof bal === "string" ? parseFloat(bal) : bal;
  return n.toLocaleString("en-NG", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function maskAccount(num: string): string {
  if (num.length <= 4) return num;
  return `•••• ${num.slice(-4)}`;
}

function adjustColor(hex: string, amount: number): string {
  const num = parseInt(hex.replace("#", ""), 16);
  const r = Math.max(0, Math.min(255, (num >> 16) + amount));
  const g = Math.max(0, Math.min(255, ((num >> 8) & 0x00ff) + amount));
  const b = Math.max(0, Math.min(255, (num & 0x0000ff) + amount));
  return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, "0")}`;
}

export function AccountCard({
  bankName,
  bankColor,
  accountNumber,
  accountName,
  balance,
  currency = "NGN",
  compact = false,
  selected = false,
  onPress,
}: AccountCardProps) {
  const colors = useColors();

  if (compact) {
    return (
      <Pressable
        onPress={onPress}
        style={({ pressed }) => [
          styles.compact,
          {
            backgroundColor: colors.card,
            borderColor: selected ? bankColor : colors.border,
            borderWidth: selected ? 2 : 1.5,
            opacity: pressed ? 0.85 : 1,
          },
        ]}
      >
        <View style={[styles.compactDot, { backgroundColor: bankColor }]} />
        <View style={{ flex: 1 }}>
          <Text style={[styles.compactBank, { color: colors.foreground }]} numberOfLines={1}>
            {bankName}
          </Text>
          <Text style={[styles.compactAcct, { color: colors.mutedForeground }]}>
            {maskAccount(accountNumber)}
          </Text>
        </View>
        <Text style={[styles.compactBal, { color: colors.foreground }]}>
          ₦{formatBalance(balance)}
        </Text>
        {selected && (
          <View style={[styles.checkCircle, { backgroundColor: bankColor }]}>
            <Feather name="check" size={12} color="#FFF" />
          </View>
        )}
      </Pressable>
    );
  }

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [styles.cardWrap, { opacity: pressed ? 0.92 : 1 }]}
    >
      <LinearGradient
        colors={[bankColor, adjustColor(bankColor, -30)]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.card}
      >
        <View style={styles.circleTopRight} />
        <View style={styles.circleBottomLeft} />

        <View style={styles.cardTop}>
          <View style={styles.bankBadge}>
            <Text style={styles.bankBadgeText}>{bankName.slice(0, 2).toUpperCase()}</Text>
          </View>
          <Text style={styles.cardBankName}>{bankName}</Text>
        </View>

        <Text style={styles.cardBalance}>₦{formatBalance(balance)}</Text>
        <Text style={styles.cardCurrency}>{currency}</Text>

        <View style={styles.cardBottom}>
          <Text style={styles.cardAcctName}>{accountName}</Text>
          <Text style={styles.cardAcctNum}>{maskAccount(accountNumber)}</Text>
        </View>
      </LinearGradient>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  cardWrap: {
    borderRadius: 20,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 5,
    marginHorizontal: 2,
  },
  card: { borderRadius: 20, padding: 22, minHeight: 170, overflow: "hidden" },
  circleTopRight: {
    position: "absolute",
    top: -40,
    right: -40,
    width: 130,
    height: 130,
    borderRadius: 65,
    backgroundColor: "rgba(255,255,255,0.12)",
  },
  circleBottomLeft: {
    position: "absolute",
    bottom: -50,
    left: -30,
    width: 150,
    height: 150,
    borderRadius: 75,
    backgroundColor: "rgba(255,255,255,0.08)",
  },
  cardTop: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 12 },
  bankBadge: {
    width: 34,
    height: 34,
    borderRadius: 10,
    backgroundColor: "rgba(255,255,255,0.25)",
    alignItems: "center",
    justifyContent: "center",
  },
  bankBadgeText: { color: "#FFF", fontSize: 13, fontFamily: "Inter_700Bold" },
  cardBankName: { color: "rgba(255,255,255,0.9)", fontSize: 14, fontFamily: "Inter_500Medium" },
  cardBalance: {
    color: "#FFFFFF",
    fontSize: 28,
    fontFamily: "Inter_700Bold",
    letterSpacing: -0.5,
    marginBottom: 2,
  },
  cardCurrency: {
    color: "rgba(255,255,255,0.7)",
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    marginBottom: 16,
  },
  cardBottom: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  cardAcctName: { color: "rgba(255,255,255,0.85)", fontSize: 13, fontFamily: "Inter_500Medium" },
  cardAcctNum: {
    color: "rgba(255,255,255,0.7)",
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    letterSpacing: 1,
  },
  compact: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 14,
    padding: 14,
    gap: 12,
  },
  compactDot: { width: 12, height: 12, borderRadius: 6 },
  compactBank: { fontSize: 14, fontFamily: "Inter_600SemiBold", marginBottom: 2 },
  compactAcct: { fontSize: 12, fontFamily: "Inter_400Regular" },
  compactBal: { fontSize: 14, fontFamily: "Inter_700Bold" },
  checkCircle: {
    width: 22,
    height: 22,
    borderRadius: 11,
    alignItems: "center",
    justifyContent: "center",
  },
});
